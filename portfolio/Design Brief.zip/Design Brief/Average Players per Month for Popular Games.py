
# Get the directory name for data files
import os.path
directory = os.path.dirname(os.path.abspath(__file__))  

#initialize the aggregators
month1=[]
player1=[]
month2=[]
player2=[]
month3=[]
player3=[]
month4=[]
player4=[]
month5=[]
player5=[]

# Scan one year's file at a time
for title in range(1,5):
    # Open the file
    filename = os.path.join(directory, 'game'+str(title)+'.csv')
    datafile = open(filename,'r')
    # Go through all the names that year
    for line in datafile:
        month, player = line.split(',')
        if title == 1:
            month1.append(month)
            player1.append(player)
        if title == 2:
            month2.append(month)
            player2.append(player)
        if title == 3:
            month3.append(month)
            player3.append(player)
        if title == 4:
            month4.append(month)
            player4.append(player)
        if title == 5:
            month5.append(month)
            player5.append(player)
    datafile.close()
    
# Plot on one set of axes.
import matplotlib.pyplot as plt
fig, ax = plt.subplots(1, 1)
ax.set_xlabel('from relesed date of game to January 2017')
ax.set_ylabel('Number of Players')
ax.plot(month1, player1, '#FF3333')
ax.plot(month2, player2, '#FFE800')
ax.plot(month3, player3, '#59FF00')
ax.plot(month4, player4, '#008FFF')
ax.plot(month5, player5, '#FF00A6')

ax.set_title('Average Players for Popular Games per Month')
fig.show()

  
    
            